"""
analysis.py
-----------
Runs the statistical analysis on the cleaned dataset and writes a
machine-readable findings file (JSON) consumed by the report generator.

Usage:
    python3 src/analysis.py
"""
import json
from pathlib import Path

import pandas as pd

CLEAN_PATH = Path(__file__).resolve().parent.parent / "data" / "car_crashes_clean.csv"
FINDINGS_PATH = Path(__file__).resolve().parent.parent / "outputs" / "findings.json"

US_STATE_NAMES = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas", "CA": "California",
    "CO": "Colorado", "CT": "Connecticut", "DE": "Delaware", "DC": "District of Columbia",
    "FL": "Florida", "GA": "Georgia", "HI": "Hawaii", "ID": "Idaho", "IL": "Illinois",
    "IN": "Indiana", "IA": "Iowa", "KS": "Kansas", "KY": "Kentucky", "LA": "Louisiana",
    "ME": "Maine", "MD": "Maryland", "MA": "Massachusetts", "MI": "Michigan", "MN": "Minnesota",
    "MS": "Mississippi", "MO": "Missouri", "MT": "Montana", "NE": "Nebraska", "NV": "Nevada",
    "NH": "New Hampshire", "NJ": "New Jersey", "NM": "New Mexico", "NY": "New York",
    "NC": "North Carolina", "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma", "OR": "Oregon",
    "PA": "Pennsylvania", "RI": "Rhode Island", "SC": "South Carolina", "SD": "South Dakota",
    "TN": "Tennessee", "TX": "Texas", "UT": "Utah", "VT": "Vermont", "VA": "Virginia",
    "WA": "Washington", "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming",
}


def load_clean() -> pd.DataFrame:
    df = pd.read_csv(CLEAN_PATH)
    df["state_name"] = df["abbrev"].map(US_STATE_NAMES)
    return df


def summary_statistics(df: pd.DataFrame) -> dict:
    numeric_cols = ["total", "speeding", "alcohol", "not_distracted", "no_previous",
                     "ins_premium", "ins_losses"]
    return df[numeric_cols].describe().round(2).to_dict()


def correlation_matrix(df: pd.DataFrame) -> dict:
    numeric_cols = ["total", "speeding", "alcohol", "not_distracted", "no_previous",
                     "ins_premium", "ins_losses"]
    return df[numeric_cols].corr().round(3).to_dict()


def top_bottom(df: pd.DataFrame, col: str, n: int = 5) -> dict:
    top = df.nlargest(n, col)[["state_name", "abbrev", col]].to_dict(orient="records")
    bottom = df.nsmallest(n, col)[["state_name", "abbrev", col]].to_dict(orient="records")
    return {"highest": top, "lowest": bottom}


def premium_vs_risk_gap(df: pd.DataFrame, n: int = 5) -> dict:
    """States where insurance premium is high/low relative to the crash rate
    would suggest, i.e. pricing that looks out of step with underlying risk.
    We standardize both variables and take the difference."""
    d = df.copy()
    d["total_z"] = (d["total"] - d["total"].mean()) / d["total"].std()
    d["premium_z"] = (d["ins_premium"] - d["ins_premium"].mean()) / d["ins_premium"].std()
    d["premium_minus_risk"] = d["premium_z"] - d["total_z"]
    over = d.nlargest(n, "premium_minus_risk")[
        ["state_name", "abbrev", "total", "ins_premium", "premium_minus_risk"]
    ].round(2).to_dict(orient="records")
    under = d.nsmallest(n, "premium_minus_risk")[
        ["state_name", "abbrev", "total", "ins_premium", "premium_minus_risk"]
    ].round(2).to_dict(orient="records")
    return {"premium_high_relative_to_risk": over, "premium_low_relative_to_risk": under}


def contributing_factor_share(df: pd.DataFrame) -> dict:
    """Average share of the crash rate attributable to each recorded factor
    (speeding, alcohol, distraction, prior-offense-free drivers)."""
    d = df.copy()
    for col in ["speeding", "alcohol", "not_distracted", "no_previous"]:
        d[f"{col}_share_pct"] = 100 * d[col] / d["total"]
    shares = d[[f"{c}_share_pct" for c in
                ["speeding", "alcohol", "not_distracted", "no_previous"]]].mean().round(1)
    return shares.to_dict()


def run() -> dict:
    df = load_clean()

    findings = {
        "n_states": int(len(df)),
        "summary_statistics": summary_statistics(df),
        "correlation_matrix": correlation_matrix(df),
        "top_bottom_total_crash_rate": top_bottom(df, "total"),
        "top_bottom_alcohol_involvement": top_bottom(df, "alcohol"),
        "top_bottom_speeding_involvement": top_bottom(df, "speeding"),
        "top_bottom_insurance_premium": top_bottom(df, "ins_premium"),
        "top_bottom_insurance_losses": top_bottom(df, "ins_losses"),
        "premium_vs_risk_gap": premium_vs_risk_gap(df),
        "avg_contributing_factor_share_pct": contributing_factor_share(df),
        "national_avg_crash_rate": round(df["total"].mean(), 2),
        "national_avg_premium": round(df["ins_premium"].mean(), 2),
        "national_avg_losses": round(df["ins_losses"].mean(), 2),
        "premium_loss_correlation": round(df["ins_premium"].corr(df["ins_losses"]), 3),
        "premium_crashrate_correlation": round(df["ins_premium"].corr(df["total"]), 3),
        "alcohol_total_correlation": round(df["alcohol"].corr(df["total"]), 3),
        "speeding_total_correlation": round(df["speeding"].corr(df["total"]), 3),
    }

    FINDINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(FINDINGS_PATH, "w") as f:
        json.dump(findings, f, indent=2, default=str)

    return findings


if __name__ == "__main__":
    f = run()
    print(json.dumps(f, indent=2, default=str))
