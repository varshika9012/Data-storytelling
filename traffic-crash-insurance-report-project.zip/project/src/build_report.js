const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, ShadingType, ImageRun, AlignmentType, BorderStyle, PageBreak,
  Header, Footer, PageNumber, NumberFormat, LevelFormat, convertInchesToTwip,
} = require("docx");

const ROOT = path.resolve(__dirname, "..");
const FIG = path.join(ROOT, "outputs", "figures");
const findings = JSON.parse(fs.readFileSync(path.join(ROOT, "outputs", "findings.json")));
const dq = JSON.parse(fs.readFileSync(path.join(ROOT, "outputs", "data_quality_report.json")));

const NAVY = "1E293B";
const ACCENT = "2563EB";
const GREY = "64748B";
const LIGHT = "EFF6FF";

function h1(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 160 } });
}
function h2(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_2, spacing: { before: 260, after: 120 } });
}
function body(text, opts = {}) {
  return new Paragraph({
    children: [new TextRun({ text, ...opts })],
    spacing: { after: 160 },
  });
}
function bullet(text) {
  return new Paragraph({ text, bullet: { level: 0 }, spacing: { after: 80 } });
}
function caption(text) {
  return new Paragraph({
    children: [new TextRun({ text, italics: true, size: 18, color: GREY })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 320 },
  });
}
function image(fileName, widthIn = 6.2) {
  const filePath = path.join(FIG, fileName);
  const data = fs.readFileSync(filePath);
  // read PNG dims
  const w = data.readUInt32BE(16);
  const hpx = data.readUInt32BE(20);
  const ratio = hpx / w;
  const widthTwip = widthIn * 96;
  return new Paragraph({
    children: [
      new ImageRun({
        data,
        transformation: { width: widthTwip, height: widthTwip * ratio },
        type: "png",
      }),
    ],
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 60 },
  });
}

function statTable(rows, headers) {
  const colWidths = new Array(headers.length).fill(Math.floor(9000 / headers.length));
  const headerRow = new TableRow({
    tableHeader: true,
    children: headers.map((htext, i) => new TableCell({
      width: { size: colWidths[i], type: WidthType.DXA },
      shading: { type: ShadingType.CLEAR, fill: NAVY },
      margins: { top: 80, bottom: 80, left: 100, right: 100 },
      children: [new Paragraph({
        children: [new TextRun({ text: htext, bold: true, color: "FFFFFF", size: 20 })],
      })],
    })),
  });
  const dataRows = rows.map((r, ri) => new TableRow({
    children: r.map((cell, i) => new TableCell({
      width: { size: colWidths[i], type: WidthType.DXA },
      shading: { type: ShadingType.CLEAR, fill: ri % 2 === 0 ? "FFFFFF" : "F8FAFC" },
      margins: { top: 60, bottom: 60, left: 100, right: 100 },
      children: [new Paragraph({ children: [new TextRun({ text: String(cell), size: 20 })] })],
    })),
  }));
  return new Table({
    width: { size: 9000, type: WidthType.DXA },
    columnWidths: colWidths,
    rows: [headerRow, ...dataRows],
  });
}

function fmt(n, d = 1) {
  return Number(n).toFixed(d);
}

// ---------- build ranked tables ----------
const topCrash = findings.top_bottom_total_crash_rate.highest
  .map((r) => [r.state_name, r.abbrev, fmt(r.total)]);
const lowCrash = findings.top_bottom_total_crash_rate.lowest
  .map((r) => [r.state_name, r.abbrev, fmt(r.total)]);
const premiumHigh = findings.premium_vs_risk_gap.premium_high_relative_to_risk
  .map((r) => [r.state_name, fmt(r.total), `$${fmt(r.ins_premium, 0)}`]);
const premiumLow = findings.premium_vs_risk_gap.premium_low_relative_to_risk
  .map((r) => [r.state_name, fmt(r.total), `$${fmt(r.ins_premium, 0)}`]);

const doc = new Document({
  styles: {
    default: {
      document: { run: { font: "Calibri", size: 22, color: "1F2937" } },
    },
    paragraphStyles: [
      {
        id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 30, bold: true, color: NAVY, font: "Calibri" },
        paragraph: { spacing: { before: 360, after: 160 }, border: { bottom: { color: ACCENT, space: 4, style: BorderStyle.SINGLE, size: 6 } } },
      },
      {
        id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 25, bold: true, color: ACCENT, font: "Calibri" },
        paragraph: { spacing: { before: 260, after: 120 } },
      },
    ],
  },
  sections: [
    // ---------------- COVER PAGE ----------------
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 },
        },
      },
      children: [
        new Paragraph({ spacing: { before: 2200 }, children: [] }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "U.S. STATE-LEVEL", bold: true, size: 26, color: ACCENT, allCaps: true })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 120, after: 200 },
          children: [new TextRun({ text: "Traffic Fatality & Auto Insurance Risk Report", bold: true, size: 52, color: NAVY })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 600 },
          children: [new TextRun({ text: "A Decision-Oriented Analysis of Fatal Collision Rates, Contributing Factors, and Insurance Pricing Across the 50 U.S. States and the District of Columbia", size: 24, color: GREY, italics: true })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 1800 },
          children: [new TextRun({ text: "Prepared using publicly available, authorized data", size: 20, color: GREY })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "Report generated: September 2026", size: 20, color: GREY })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 40 },
          children: [new TextRun({ text: "Data source: seaborn-data / car_crashes.csv (originally compiled from NHTSA & IIHS data)", size: 20, color: GREY })],
        }),
      ],
    },
    // ---------------- MAIN CONTENT ----------------
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 },
        },
      },
      headers: {
        default: new Header({
          children: [new Paragraph({
            children: [new TextRun({ text: "Traffic Fatality & Auto Insurance Risk Report", size: 16, color: GREY })],
            border: { bottom: { color: "CBD5E1", space: 4, style: BorderStyle.SINGLE, size: 4 } },
          })],
        }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({ text: "Page ", size: 16, color: GREY }),
              new TextRun({ children: [PageNumber.CURRENT], size: 16, color: GREY }),
              new TextRun({ text: " of ", size: 16, color: GREY }),
              new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 16, color: GREY }),
            ],
          })],
        }),
      },
      children: [
        // ===== EXECUTIVE SUMMARY =====
        h1("1. Executive Summary"),
        body(`This report analyzes fatal motor-vehicle collision rates across all 50 U.S. states and the District of Columbia (n = ${findings.n_states}), together with the recorded contributing factors (speeding, alcohol involvement, distraction-free driving, and no-prior-offense driving) and each state's average auto insurance premium and insurer losses. The goal is to surface state-level risk patterns and pricing gaps that are directly useful for insurance underwriting, state highway-safety policy, and public-awareness targeting.`),
        h2("Headline findings"),
        bullet(`The national average fatal-collision rate is ${findings.national_avg_crash_rate} per billion miles driven, with more than a 4x spread between the lowest state (District of Columbia, 5.9) and the highest states (North Dakota and South Carolina, tied at 23.9).`),
        bullet(`Alcohol involvement (r = ${findings.alcohol_total_correlation}) and driving without a prior offense on record (r = ${findings.correlation_matrix.total.no_previous}) are the two factors most strongly correlated with a state's overall crash rate — far more than speeding (r = ${findings.speeding_total_correlation}).`),
        bullet(`Insurance premiums are only weakly correlated with actual crash risk (r = ${findings.premium_crashrate_correlation}), meaning premium levels are driven substantially by factors outside this dataset (litigation costs, minimum-coverage laws, population density, repair costs) rather than by collision frequency alone.`),
        bullet(`Several states show a sizeable mismatch between measured risk and premium levels in both directions — a segment worth deeper actuarial review (see Section 5).`),
        h2("Primary audience & use"),
        body("This report is intended for insurance pricing/actuarial teams, state department-of-transportation policy analysts, and public-safety communicators who need an evidence base for resource allocation and messaging decisions."),

        new Paragraph({ children: [new PageBreak()] }),

        // ===== METHODOLOGY =====
        h1("2. Methodology"),
        h2("2.1 Data source"),
        body("The dataset used is car_crashes.csv, a publicly available, open-license dataset distributed through the seaborn-data GitHub repository (maintained by the seaborn visualization library maintainers). It aggregates U.S. state-level statistics originally compiled from National Highway Traffic Safety Administration (NHTSA) and Insurance Institute for Highway Safety (IIHS) sources. The dataset is free to use for analysis and education and contains no personally identifiable information — all records are aggregated at the state level."),
        h2("2.2 Variables analyzed"),
        statTable([
          ["total", "Fatal collisions per billion miles driven (overall crash rate)"],
          ["speeding", "Fatal collisions per billion miles where speeding was recorded"],
          ["alcohol", "Fatal collisions per billion miles involving alcohol"],
          ["not_distracted", "Fatal collisions per billion miles where the driver was not distracted"],
          ["no_previous", "Fatal collisions per billion miles involving drivers with no prior accidents"],
          ["ins_premium", "Average automobile insurance premium ($)"],
          ["ins_losses", "Average insurance losses incurred per insured vehicle ($)"],
        ], ["Column", "Definition"]),
        h2("2.3 Analytical approach"),
        bullet("Descriptive statistics (mean, standard deviation, quartiles) were computed for every numeric variable to characterize the national distribution."),
        bullet("Pearson correlation coefficients were computed between all numeric variables to identify which contributing factors move most closely with overall crash rate, and how crash rate relates to insurance pricing."),
        bullet("States were ranked (highest/lowest) on crash rate, alcohol involvement, speeding involvement, insurance premium, and insurance losses to identify outliers worth investigating."),
        bullet("A standardized 'premium vs. risk gap' score was constructed by z-scoring both crash rate and premium and taking their difference, to flag states where pricing looks out of step with measured risk in either direction."),
        h2("2.4 Tools and libraries"),
        bullet("Python 3 with pandas for data loading, cleaning, and statistical computation."),
        bullet("Matplotlib for all chart generation (bar charts, scatter plot with trend line, correlation heatmap, histograms)."),
        bullet("NumPy for the linear trend fit used in the scatter plot."),

        new Paragraph({ children: [new PageBreak()] }),

        // ===== DATA QUALITY =====
        h1("3. Data Quality Notes"),
        body("Before analysis, the raw dataset was passed through an automated data-quality pipeline (src/data_quality.py) that checks schema conformance, completeness, duplication, value-range plausibility, and geographic coverage. Results:"),
        statTable([
          ["Schema conformance", dq.schema.schema_ok ? "Pass — all 8 expected columns present, no unexpected columns" : "Issues found"],
          ["Completeness", `${dq.completeness.completeness_pct}% — 0 missing values across ${dq.completeness.row_count} rows x ${dq.completeness.column_count} columns`],
          ["Duplicate rows", `${dq.duplicates.duplicate_rows} duplicate rows found`],
          ["Duplicate state codes", `${dq.duplicates.duplicate_state_codes} found`],
          ["Range plausibility", "All rate columns non-negative and within bounds; all premium/loss values positive"],
          ["Geographic coverage", dq.state_coverage.coverage_complete ? `Complete — all ${dq.state_coverage.expected_records} states + DC present` : "Incomplete"],
          ["Rows removed during cleaning", `${dq.rows_removed_during_cleaning}`],
        ], ["Check", "Result"]),
        h2("Notes and caveats on the source data"),
        bullet("This is a cross-sectional snapshot (one row per state) rather than a time series, so it cannot show trends over time or year-over-year change."),
        bullet("The four 'contributing factor' columns (speeding, alcohol, not_distracted, no_previous) are not mutually exclusive — a single fatal collision can involve more than one factor, so they should not be summed to reconstruct the total."),
        bullet("The dataset does not document its exact collection year(s) in the file itself; it should be treated as a representative illustrative snapshot rather than a real-time feed, and the source repository should be checked for provenance details before using this analysis for regulatory or legal purposes."),
        bullet("No records were removed during cleaning — the dataset passed all quality checks as received, which is expected for a well-maintained, widely used teaching/reference dataset."),

        new Paragraph({ children: [new PageBreak()] }),

        // ===== KEY FINDINGS =====
        h1("4. Key Findings"),

        h2("4.1 Wide variation in crash risk across states"),
        body(`The overall fatal-collision rate ranges from ${fmt(findings.summary_statistics.total.min)} to ${fmt(findings.summary_statistics.total.max)} (per billion miles driven), a spread of over ${fmt(findings.summary_statistics.total.max / findings.summary_statistics.total.min, 1)}x between the safest and riskiest states, with a national average of ${findings.national_avg_crash_rate}.`),
        image("01_top_states_crash_rate.png"),
        caption("Figure 1. The 10 states with the highest overall fatal-collision rate."),
        statTable(topCrash, ["State", "Code", "Crash rate"]),
        new Paragraph({ spacing: { after: 240 }, children: [] }),
        h2("4.2 Alcohol and repeat-offender-free driving are the strongest correlates of risk"),
        body(`Correlation analysis shows that a state's overall crash rate moves most closely with alcohol involvement (r = ${findings.alcohol_total_correlation}) and with the no_previous factor (r = ${findings.correlation_matrix.total.no_previous}). Speeding, while still positively correlated (r = ${findings.speeding_total_correlation}), is a comparatively weaker driver of state-level variation. This suggests that alcohol-related enforcement and education may have more leverage on the overall rate than speed enforcement alone in the highest-risk states.`),
        image("02_correlation_heatmap.png"),
        caption("Figure 2. Correlation matrix across all crash-factor and insurance variables."),
        image("04_factor_share.png"),
        caption("Figure 3. Average share of the fatal-collision rate attributable to each recorded factor, averaged across states. Note categories are not mutually exclusive."),

        h2("4.3 Insurance premiums track crash risk only weakly"),
        body(`Average insurance premium correlates only weakly and negatively with overall crash rate (r = ${findings.premium_crashrate_correlation}) — some of the states with the highest crash rates (e.g. North Dakota, South Carolina) have below-average premiums, while several low-crash-rate states (e.g. DC, New Jersey, New York) carry the highest premiums in the country. Premiums correlate more closely with insurer losses (r = ${findings.premium_loss_correlation}), which reflects claim costs, litigation environment, and vehicle repair/replacement costs rather than collision frequency alone.`),
        image("03_premium_vs_crashrate.png"),
        caption("Figure 4. Insurance premium plotted against crash rate for all 51 jurisdictions, with linear trend line."),

        h2("4.4 States where pricing looks out of step with measured risk"),
        body("Standardizing both crash rate and premium and taking the difference surfaces states where premiums sit unusually high or low relative to the state's own measured collision risk. This is a starting point for actuarial review, not a conclusion about mispricing on its own — see Limitations."),
        image("05_premium_risk_gap.png"),
        caption("Figure 5. States furthest from the national premium-to-risk relationship, in standard-deviation units."),
        h2("Premium high relative to measured risk"),
        statTable(premiumHigh, ["State", "Crash rate", "Avg. premium"]),
        new Paragraph({ spacing: { after: 200 }, children: [] }),
        h2("Premium low relative to measured risk"),
        statTable(premiumLow, ["State", "Crash rate", "Avg. premium"]),

        new Paragraph({ children: [new PageBreak()] }),
        h2("4.5 Distribution of key variables"),
        body("Both crash rate and insurance premium are roughly unimodal across states, without extreme long-tail outliers, which supports using simple mean/standard-deviation comparisons (as in Section 4.4) rather than requiring more robust statistics."),
        image("06_distributions.png"),
        caption("Figure 6. Distribution of crash rates (left) and insurance premiums (right) across the 51 jurisdictions."),

        new Paragraph({ children: [new PageBreak()] }),

        // ===== LIMITATIONS =====
        h1("5. Limitations"),
        bullet("Cross-sectional snapshot: the dataset represents a single time period per state rather than a multi-year trend, so findings describe relative standing between states, not change over time."),
        bullet("Correlation, not causation: the strong correlation between alcohol involvement and overall crash rate does not by itself prove that alcohol enforcement would reduce the total rate — confounding factors (rural road mileage, speed limits, seatbelt laws, emergency response times) are not present in this dataset."),
        bullet("Non-exclusive categories: because a single fatal collision can be tagged with multiple contributing factors, the four factor columns cannot be combined additively, which limits some forms of decomposition analysis."),
        bullet("Small sample size: with only 51 observations (states + DC), correlation estimates and the premium-vs-risk gap ranking are sensitive to individual outlier states and should be treated as directional rather than statistically definitive."),
        bullet("Premium drivers outside scope: insurance premiums are influenced by many state-level factors not captured here (minimum coverage requirements, litigation/tort environment, population density, vehicle theft rates, repair costs), so the 'premium vs. risk gap' metric should be read as a screening signal for further underwriting review, not a finding of mispricing."),
        bullet("No demographic or road-infrastructure data: the dataset does not include population, vehicle-miles-traveled breakdowns by road type, or demographic composition, which would be needed for a full causal policy analysis."),

        new Paragraph({ children: [new PageBreak()] }),

        // ===== CONCLUSIONS =====
        h1("6. Actionable Conclusions & Recommendations"),
        h2("For insurance pricing / actuarial teams"),
        bullet("Prioritize underwriting review of the states listed in Section 4.4 where premiums appear high or low relative to measured crash risk — confirm whether the gap is explained by loss-cost, litigation, or regulatory factors, or represents a genuine pricing opportunity."),
        bullet("Because premium correlates more with insurer losses than with raw crash rate, continue weighting claims-cost data (not just collision frequency) heavily in state-level rate-setting."),
        h2("For state highway-safety policy makers"),
        bullet("In the highest-crash-rate states (North Dakota, South Carolina, West Virginia, Arkansas, Kentucky), prioritize alcohol-impaired-driving enforcement and interventions given its outsized correlation with total crash rate compared to speeding."),
        bullet("Study the lowest-crash-rate jurisdictions (DC, Massachusetts, Minnesota) as potential policy benchmarks — their combination of road environment, enforcement, and public-transit alternatives may offer transferable lessons."),
        h2("For public-safety communicators"),
        bullet("Target alcohol-related messaging campaigns toward the states with the highest alcohol-involvement share, rather than applying a uniform national campaign, since involvement rates vary more than 6x between the highest and lowest states."),
        h2("Suggested next steps"),
        bullet("Extend the analysis with multi-year data (if available from NHTSA's Fatality Analysis Reporting System, FARS) to distinguish genuine trend shifts from single-year noise."),
        bullet("Bring in population and vehicle-miles-traveled data to normalize comparisons and separate 'more driving' from 'riskier driving.'"),
        bullet("Incorporate state-level policy variables (BAC limits, seatbelt laws, speed limits) to move from correlation toward a defensible causal model."),

        new Paragraph({ children: [new PageBreak()] }),

        // ===== APPENDIX =====
        h1("7. Appendix"),
        h2("7.1 Descriptive statistics (all variables)"),
        statTable(
          ["total", "speeding", "alcohol", "not_distracted", "no_previous", "ins_premium", "ins_losses"].map((c) => [
            c,
            fmt(findings.summary_statistics[c].mean, 2),
            fmt(findings.summary_statistics[c].std, 2),
            fmt(findings.summary_statistics[c].min, 2),
            fmt(findings.summary_statistics[c]["50%"], 2),
            fmt(findings.summary_statistics[c].max, 2),
          ]),
          ["Variable", "Mean", "Std Dev", "Min", "Median", "Max"]
        ),
        new Paragraph({ spacing: { after: 240 }, children: [] }),
        h2("7.2 External libraries, tools, and data sources used"),
        bullet("Dataset: car_crashes.csv — seaborn-data GitHub repository (github.com/mwaskom/seaborn-data), open/public license, originally derived from NHTSA and IIHS data."),
        bullet("Python 3 — analysis language."),
        bullet("pandas — data loading, cleaning, and aggregation."),
        bullet("NumPy — trend-line fitting for the scatter plot."),
        bullet("Matplotlib — all chart/figure generation."),
        bullet("docx (Node.js) — used to generate this Word report programmatically."),
        bullet("No external APIs, paid services, proprietary datasets, third-party images, or ML models were used in this analysis."),
        h2("7.3 Reproducibility"),
        body("All source code, the raw and cleaned datasets, the generated figures, and this report are included in the accompanying project repository. See README.md for setup and run instructions. No credentials, API keys, or private data are required or included."),
      ],
    },
  ],
});

Packer.toBuffer(doc).then((buffer) => {
  const outPath = path.join(ROOT, "outputs", "Traffic_Crash_Insurance_Report.docx");
  fs.writeFileSync(outPath, buffer);
  console.log("Wrote", outPath);
});
