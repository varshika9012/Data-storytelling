"""
data_quality.py
----------------
Performs data-quality checks on the raw dataset and produces a
machine-readable quality report (JSON) plus a cleaned CSV.

Usage:
    python3 src/data_quality.py
"""
import json
import pandas as pd
from pathlib import Path

RAW_PATH = Path(__file__).resolve().parent.parent / "data" / "car_crashes.csv"
CLEAN_PATH = Path(__file__).resolve().parent.parent / "data" / "car_crashes_clean.csv"
REPORT_PATH = Path(__file__).resolve().parent.parent / "outputs" / "data_quality_report.json"

EXPECTED_COLUMNS = [
    "total", "speeding", "alcohol", "not_distracted",
    "no_previous", "ins_premium", "ins_losses", "abbrev",
]

NUMERIC_COLUMNS = [
    "total", "speeding", "alcohol", "not_distracted",
    "no_previous", "ins_premium", "ins_losses",
]


def load_raw(path: Path = RAW_PATH) -> pd.DataFrame:
    df = pd.read_csv(path)
    return df


def check_schema(df: pd.DataFrame) -> dict:
    missing_cols = [c for c in EXPECTED_COLUMNS if c not in df.columns]
    extra_cols = [c for c in df.columns if c not in EXPECTED_COLUMNS]
    return {
        "expected_columns": EXPECTED_COLUMNS,
        "missing_columns": missing_cols,
        "unexpected_columns": extra_cols,
        "schema_ok": not missing_cols and not extra_cols,
    }


def check_completeness(df: pd.DataFrame) -> dict:
    null_counts = df.isnull().sum().to_dict()
    total_cells = df.shape[0] * df.shape[1]
    total_nulls = int(df.isnull().sum().sum())
    return {
        "row_count": int(df.shape[0]),
        "column_count": int(df.shape[1]),
        "null_counts_by_column": {k: int(v) for k, v in null_counts.items()},
        "total_nulls": total_nulls,
        "completeness_pct": round(100 * (1 - total_nulls / total_cells), 2),
    }


def check_duplicates(df: pd.DataFrame) -> dict:
    dup_rows = int(df.duplicated().sum())
    dup_states = int(df["abbrev"].duplicated().sum()) if "abbrev" in df.columns else None
    return {"duplicate_rows": dup_rows, "duplicate_state_codes": dup_states}


def check_ranges(df: pd.DataFrame) -> dict:
    """Flag values that are structurally impossible for this dataset:
    all rate/percentage-style columns must be within [0, 100] and non-negative,
    ins_premium and ins_losses must be positive dollar amounts."""
    issues = {}
    for col in ["speeding", "alcohol", "not_distracted", "no_previous"]:
        if col in df.columns:
            out_of_range = df[(df[col] < 0) | (df[col] > df["total"])]
            issues[col] = int(len(out_of_range))
    for col in ["ins_premium", "ins_losses", "total"]:
        if col in df.columns:
            issues[f"{col}_non_positive"] = int((df[col] <= 0).sum())
    return issues


def check_state_coverage(df: pd.DataFrame) -> dict:
    us_states_plus_dc = 51  # 50 states + District of Columbia
    return {
        "expected_records": us_states_plus_dc,
        "actual_records": int(len(df)),
        "coverage_complete": len(df) == us_states_plus_dc,
    }


def run(raw_path: Path = RAW_PATH) -> dict:
    df = load_raw(raw_path)

    report = {
        "source_file": str(raw_path.name),
        "schema": check_schema(df),
        "completeness": check_completeness(df),
        "duplicates": check_duplicates(df),
        "range_checks": check_ranges(df),
        "state_coverage": check_state_coverage(df),
    }

    # Cleaning: for this dataset no nulls/duplicates were found upstream,
    # but the pipeline is defensive in case source data changes.
    clean_df = df.drop_duplicates()
    for col in NUMERIC_COLUMNS:
        clean_df[col] = pd.to_numeric(clean_df[col], errors="coerce")
    clean_df = clean_df.dropna(subset=NUMERIC_COLUMNS)
    clean_df["abbrev"] = clean_df["abbrev"].str.strip().str.upper()

    report["rows_removed_during_cleaning"] = int(len(df) - len(clean_df))
    report["final_row_count"] = int(len(clean_df))

    CLEAN_PATH.parent.mkdir(parents=True, exist_ok=True)
    clean_df.to_csv(CLEAN_PATH, index=False)

    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(REPORT_PATH, "w") as f:
        json.dump(report, f, indent=2)

    return report


if __name__ == "__main__":
    rep = run()
    print(json.dumps(rep, indent=2))
