"""
visualize.py
------------
Generates all charts used in the report and saves them as PNG files
under outputs/figures/. Uses matplotlib (+ seaborn styling only for
the correlation heatmap colormap, no seaborn plotting calls).

Usage:
    python3 src/visualize.py
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

CLEAN_PATH = Path(__file__).resolve().parent.parent / "data" / "car_crashes_clean.csv"
FIG_DIR = Path(__file__).resolve().parent.parent / "outputs" / "figures"

plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "axes.edgecolor": "#444444",
    "axes.labelcolor": "#222222",
    "text.color": "#222222",
    "xtick.color": "#222222",
    "ytick.color": "#222222",
    "font.size": 11,
    "axes.titlesize": 14,
    "axes.titleweight": "bold",
})

ACCENT = "#2563EB"
ACCENT2 = "#DC2626"
ACCENT3 = "#059669"


def load() -> pd.DataFrame:
    return pd.read_csv(CLEAN_PATH)


def fig_top_states_crash_rate(df: pd.DataFrame):
    d = df.nlargest(10, "total").sort_values("total")
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.barh(d["abbrev"], d["total"], color=ACCENT)
    ax.set_xlabel("Fatal collisions per billion miles driven")
    ax.set_title("Top 10 States by Overall Crash Rate")
    for i, v in enumerate(d["total"]):
        ax.text(v + 0.2, i, f"{v:.1f}", va="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "01_top_states_crash_rate.png", dpi=150)
    plt.close(fig)


def fig_correlation_heatmap(df: pd.DataFrame):
    cols = ["total", "speeding", "alcohol", "not_distracted", "no_previous",
            "ins_premium", "ins_losses"]
    corr = df[cols].corr()
    fig, ax = plt.subplots(figsize=(8, 6.5))
    im = ax.imshow(corr, cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_xticks(range(len(cols)))
    ax.set_yticks(range(len(cols)))
    ax.set_xticklabels(cols, rotation=45, ha="right")
    ax.set_yticklabels(cols)
    for i in range(len(cols)):
        for j in range(len(cols)):
            ax.text(j, i, f"{corr.iloc[i, j]:.2f}", ha="center", va="center",
                     fontsize=8, color="white" if abs(corr.iloc[i, j]) > 0.5 else "black")
    fig.colorbar(im, ax=ax, shrink=0.8, label="Correlation coefficient")
    ax.set_title("Correlation Matrix: Crash Factors & Insurance Metrics")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "02_correlation_heatmap.png", dpi=150)
    plt.close(fig)


def fig_premium_vs_crashrate_scatter(df: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(df["total"], df["ins_premium"], color=ACCENT, alpha=0.75, s=60,
               edgecolor="white", linewidth=0.5)
    z = np.polyfit(df["total"], df["ins_premium"], 1)
    xs = np.linspace(df["total"].min(), df["total"].max(), 100)
    ax.plot(xs, np.polyval(z, xs), color=ACCENT2, linestyle="--", linewidth=2,
            label=f"Trend (r = {df['total'].corr(df['ins_premium']):.2f})")
    for _, row in df.nlargest(3, "total").iterrows():
        ax.annotate(row["abbrev"], (row["total"], row["ins_premium"]),
                    textcoords="offset points", xytext=(5, 5), fontsize=8)
    ax.set_xlabel("Overall crash rate (fatal collisions per billion miles)")
    ax.set_ylabel("Average car insurance premium ($)")
    ax.set_title("Insurance Premium vs. Crash Rate by State")
    ax.legend()
    fig.tight_layout()
    fig.savefig(FIG_DIR / "03_premium_vs_crashrate.png", dpi=150)
    plt.close(fig)


def fig_factor_share_bar(df: pd.DataFrame):
    factors = ["speeding", "alcohol", "not_distracted", "no_previous"]
    labels = ["Speeding", "Alcohol", "Not Distracted*", "No Prior Offense*"]
    shares = [100 * (df[f] / df["total"]).mean() for f in factors]
    fig, ax = plt.subplots(figsize=(8, 5.5))
    bars = ax.bar(labels, shares, color=[ACCENT, ACCENT2, ACCENT3, "#7C3AED"])
    for b, s in zip(bars, shares):
        ax.text(b.get_x() + b.get_width() / 2, s + 1, f"{s:.0f}%", ha="center", fontsize=10)
    ax.set_ylabel("Average share of fatal-collision rate (%)")
    ax.set_title("Average Contribution of Each Recorded Factor\n(National Average Across States)")
    ax.set_ylim(0, 100)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "04_factor_share.png", dpi=150)
    plt.close(fig)


def fig_premium_risk_gap(df: pd.DataFrame):
    d = df.copy()
    d["total_z"] = (d["total"] - d["total"].mean()) / d["total"].std()
    d["premium_z"] = (d["ins_premium"] - d["ins_premium"].mean()) / d["ins_premium"].std()
    d["gap"] = d["premium_z"] - d["total_z"]
    d = d.sort_values("gap")
    top = pd.concat([d.head(6), d.tail(6)])
    colors = [ACCENT2 if v > 0 else ACCENT for v in top["gap"]]
    fig, ax = plt.subplots(figsize=(8, 7))
    ax.barh(top["abbrev"], top["gap"], color=colors)
    ax.axvline(0, color="#444444", linewidth=1)
    ax.set_xlabel("Premium standardized score minus crash-rate standardized score")
    ax.set_title("States Where Insurance Pricing Looks Out of Step\nwith Underlying Crash Risk")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "05_premium_risk_gap.png", dpi=150)
    plt.close(fig)


def fig_distribution_histogram(df: pd.DataFrame):
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
    axes[0].hist(df["total"], bins=12, color=ACCENT, edgecolor="white")
    axes[0].axvline(df["total"].mean(), color=ACCENT2, linestyle="--",
                     label=f"Mean = {df['total'].mean():.1f}")
    axes[0].set_title("Distribution of Crash Rates")
    axes[0].set_xlabel("Fatal collisions per billion miles")
    axes[0].legend()

    axes[1].hist(df["ins_premium"], bins=12, color=ACCENT3, edgecolor="white")
    axes[1].axvline(df["ins_premium"].mean(), color=ACCENT2, linestyle="--",
                     label=f"Mean = ${df['ins_premium'].mean():.0f}")
    axes[1].set_title("Distribution of Insurance Premiums")
    axes[1].set_xlabel("Average premium ($)")
    axes[1].legend()

    fig.suptitle("Spread of Key Variables Across the 50 States + DC", fontweight="bold")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "06_distributions.png", dpi=150)
    plt.close(fig)


def run():
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    df = load()
    fig_top_states_crash_rate(df)
    fig_correlation_heatmap(df)
    fig_premium_vs_crashrate_scatter(df)
    fig_factor_share_bar(df)
    fig_premium_risk_gap(df)
    fig_distribution_histogram(df)
    print(f"Saved {len(list(FIG_DIR.glob('*.png')))} figures to {FIG_DIR}")


if __name__ == "__main__":
    run()
