# Traffic Fatality & Auto Insurance Risk Report

A complete, reproducible analytics project that turns a public, authorized dataset of
U.S. state-level fatal-collision statistics into a **professional, decision-oriented
Word report** — with automated data-quality checks, statistical analysis, charts, and
actionable recommendations for insurance, policy, and public-safety audiences.

**Main deliverable:** [`outputs/Traffic_Crash_Insurance_Report.docx`](outputs/Traffic_Crash_Insurance_Report.docx)

---

## 1. What this project does

1. **Loads** a public dataset of fatal motor-vehicle collision rates and insurance
   metrics for all 50 U.S. states + DC.
2. **Validates data quality** (schema, completeness, duplicates, value ranges,
   geographic coverage) and writes a machine-readable quality report.
3. **Analyzes** the data with pandas: descriptive statistics, correlations,
   state rankings, and a "premium vs. risk gap" screening metric.
4. **Visualizes** the findings with matplotlib (6 charts).
5. **Generates** a polished, multi-section Word (`.docx`) report — cover page,
   methodology, data-quality notes, key findings with embedded charts,
   limitations, and actionable conclusions — entirely from code, so it can be
   re-run any time the underlying data changes.

Everything is scripted end-to-end; running one command reproduces the whole
pipeline from raw CSV to finished report.

---

## 2. Project structure

```
project/
├── data/
│   ├── car_crashes.csv            # raw dataset (downloaded from the source below)
│   └── car_crashes_clean.csv      # output of the data-quality/cleaning step
├── src/
│   ├── data_quality.py            # schema/completeness/duplicate/range checks + cleaning
│   ├── analysis.py                # descriptive stats, correlations, rankings
│   ├── visualize.py                # matplotlib chart generation
│   └── build_report.js            # assembles the final .docx report (docx / docx-js)
├── outputs/
│   ├── data_quality_report.json   # machine-readable QA results
│   ├── findings.json              # machine-readable analysis results
│   ├── figures/                   # 6 PNG charts used in the report
│   ├── screenshots/               # screenshots of the report & charts (see below)
│   └── Traffic_Crash_Insurance_Report.docx   # <-- final deliverable
├── docs/
│   └── DEMO_VIDEO.md              # what the short demo video covers / how to record it
├── run_pipeline.sh                # one-command pipeline runner
├── requirements.txt               # Python dependencies
├── package.json                   # Node dependency (docx) for report generation
└── README.md                      # this file
```

---

## 3. Data source

| | |
|---|---|
| **Dataset** | `car_crashes.csv` |
| **Source** | [seaborn-data GitHub repository](https://github.com/mwaskom/seaborn-data) (maintained by the maintainers of the seaborn visualization library) |
| **License** | Open / freely redistributable for analysis and educational use |
| **Original compiler** | Aggregated from U.S. National Highway Traffic Safety Administration (NHTSA) and Insurance Institute for Highway Safety (IIHS) statistics |
| **Grain** | One row per U.S. state + District of Columbia (51 rows) |
| **PII** | None — all data is aggregated at the state level |

This is a legally sourced, publicly authorized dataset commonly used for
teaching and reference (it also ships as a bundled example dataset with the
`seaborn` Python library). No scraping, paid data, or private/credentialed
sources were used.

---

## 4. Setup

### Prerequisites
- Python 3.9+
- Node.js 18+
- `pandoc` / LibreOffice are **not** required to just build the report — only
  `docx` (npm) is needed for generation. (They're only used if you want to
  re-render the .docx to PDF/JPEG for review, as described in step 6 below.)

### Install dependencies

```bash
# Python dependencies
pip install -r requirements.txt

# Node dependency (docx) for report generation
npm install
```

---

## 5. Usage

### Option A — run the whole pipeline in one step

```bash
./run_pipeline.sh
```

This runs, in order: data-quality checks → analysis → chart generation →
report build, and prints where every output file lands.

### Option B — run each stage individually

```bash
python3 src/data_quality.py   # -> data/car_crashes_clean.csv, outputs/data_quality_report.json
python3 src/analysis.py       # -> outputs/findings.json
python3 src/visualize.py      # -> outputs/figures/*.png
node src/build_report.js      # -> outputs/Traffic_Crash_Insurance_Report.docx
```

### Re-running with new data

Replace `data/car_crashes.csv` with an updated extract that has the same
column names (`total, speeding, alcohol, not_distracted, no_previous,
ins_premium, ins_losses, abbrev`) and re-run `./run_pipeline.sh` — every
downstream file, chart, and the report itself will regenerate automatically
from the new numbers.

---

## 6. Main functionality demonstration

To visually verify the generated report (used to produce the screenshots in
`outputs/screenshots/`):

```bash
cd outputs
python3 /mnt/skills/public/docx/scripts/office/soffice.py --headless --convert-to pdf Traffic_Crash_Insurance_Report.docx
pdftoppm -jpeg -r 100 Traffic_Crash_Insurance_Report.pdf page
```

This requires LibreOffice (`soffice`) and Poppler (`pdftoppm`) — standard,
freely available open-source tools, only needed for this optional
verification step, not for generating the report itself.

See `outputs/screenshots/` for pre-generated screenshots of:
- The report cover page
- The data-quality section
- A key-findings section with an embedded chart
- Two of the six analytical charts on their own

---

## 7. Report contents

The generated `.docx` report includes:

1. **Executive Summary** — headline findings and intended audience
2. **Methodology** — data source, variables, analytical approach, tools used
3. **Data Quality Notes** — automated QA results and caveats on the source data
4. **Key Findings** — 5 sub-sections, each with a chart, supporting table, and narrative
5. **Limitations** — explicit statement of what the data cannot support
6. **Actionable Conclusions & Recommendations** — separate guidance for
   insurance/actuarial teams, policy makers, and public-safety communicators
7. **Appendix** — full descriptive statistics table, list of external
   libraries/tools/data sources, and reproducibility notes

---

## 8. External libraries, tools, APIs, and datasets used

| Name | Purpose | Type |
|---|---|---|
| [pandas](https://pandas.pydata.org/docs/) | Data loading, cleaning, aggregation | Python library |
| [NumPy](https://numpy.org/doc/) | Linear trend fit for scatter plot | Python library |
| [Matplotlib](https://matplotlib.org/stable/) | All chart/figure generation | Python library |
| [docx (npm)](https://www.npmjs.com/package/docx) | Programmatic Word document generation | Node.js library |
| [car_crashes.csv](https://github.com/mwaskom/seaborn-data) | Source dataset (NHTSA/IIHS-derived) | Public dataset |
| LibreOffice / Poppler (`pdftoppm`) | Optional: rendering the .docx to images for QA/screenshots | Open-source CLI tools |

No paid APIs, proprietary data, third-party images, pretrained ML models, or
scraped content were used anywhere in this project.

---

## 9. Security note

No passwords, API keys, tokens, or other credentials are used or required
anywhere in this project — every step runs entirely offline against local
files once the public CSV has been downloaded.

---

## 10. GitHub repository

This project is packaged to be pushed directly to a new GitHub repository:

```bash
git init
git add .
git commit -m "Initial commit: traffic crash & insurance risk report pipeline"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

(No repository URL is included here since this project was generated in a
sandboxed environment without an authenticated GitHub account — push it to
your own account/org and add the URL to this section.)

---

## 11. Demo video

See [`docs/DEMO_VIDEO.md`](docs/DEMO_VIDEO.md) for a suggested script and
recording instructions for the short demonstration video required in the
submission checklist.
