#!/usr/bin/env bash
# run_pipeline.sh
# Reproduces the full analysis: data quality checks -> analysis -> charts -> report.
set -euo pipefail

echo "Step 1/4: Data quality checks..."
python3 src/data_quality.py

echo "Step 2/4: Statistical analysis..."
python3 src/analysis.py

echo "Step 3/4: Generating charts..."
python3 src/visualize.py

echo "Step 4/4: Building Word report..."
node src/build_report.js

echo ""
echo "Done. Outputs are in ./outputs:"
echo "  - outputs/data_quality_report.json"
echo "  - outputs/findings.json"
echo "  - outputs/figures/*.png"
echo "  - outputs/Traffic_Crash_Insurance_Report.docx"
