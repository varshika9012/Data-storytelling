# Demo Video (60-second version)

A screen recording could not be produced inside this sandboxed environment
(no screen/audio capture available here). Below is a tight 60-second script —
no narration needed, just do these on screen with optional text captions.

## Suggested script

**0:00 – 0:10 — Show the folder**
Open the project folder. Point at `src/`, `data/`, `outputs/`. Caption:
"Public dataset → code → auto-generated report."

**0:10 – 0:35 — Run it**
```bash
./run_pipeline.sh
```
Let the 4 steps print on screen (data quality → analysis → charts → report).

**0:35 – 0:55 — Scroll the report**
Open `outputs/Traffic_Crash_Insurance_Report.docx`. Fast-scroll past: cover →
one chart → limitations → conclusions.

**0:55 – 1:00 — End card**
Caption: "Fully reproducible — swap the CSV and rerun."

## Recording tips
- 1080p, no audio narration required if you prefer captions/text overlay instead.
- Keep the terminal font large enough to read in the recording.
- Trim dead air at the start/end before exporting.
- Export as `.mp4` and add it to `outputs/` or a `demo/` folder before pushing
  to GitHub (video files are usually excluded from git via `.gitignore` if
  large — consider linking to a hosted version, e.g. on YouTube unlisted or
  Google Drive, from the README instead of committing a large binary).
